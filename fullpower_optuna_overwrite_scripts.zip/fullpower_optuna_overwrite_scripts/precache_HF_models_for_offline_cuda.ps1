# Cache Hugging Face models before running in offline mode.
# Run this once while internet is available.
cd C:\laborshed_autocode
.\.venv\Scripts\Activate.ps1

$env:PYTHONUTF8="1"
$env:PYTHONIOENCODING="utf-8"
$env:HF_HOME="C:\laborshed_autocode\hf_cache"
$env:HF_HUB_CACHE="C:\laborshed_autocode\hf_cache\hub"
$env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"
$env:TOKENIZERS_PARALLELISM="false"
Remove-Item Env:\HF_HUB_OFFLINE -ErrorAction SilentlyContinue
Remove-Item Env:\TRANSFORMERS_OFFLINE -ErrorAction SilentlyContinue

.\.venv\Scripts\python.exe -c "from sentence_transformers import SentenceTransformer, CrossEncoder; import torch; print('cuda', torch.cuda.is_available()); SentenceTransformer('BAAI/bge-large-en-v1.5', device='cuda'); CrossEncoder('cross-encoder/ms-marco-MiniLM-L6-v2', device='cuda'); print('models cached')"
