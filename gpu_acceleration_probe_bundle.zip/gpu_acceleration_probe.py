#!/usr/bin/env python3
"""GPU/OpenVINO acceleration probe for the NAICS/SOC autocoder environment.

Run inside the same .venv used by the autocoder:
  .\.venv\Scripts\python.exe gpu_acceleration_probe.py --samples 64

It does not modify the autocoder. It reports which accelerators are visible and,
optionally, benchmarks SentenceTransformer embedding and CrossEncoder scoring on
available backends.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List


def run_cmd(cmd: List[str], timeout: int = 20) -> Dict[str, Any]:
    try:
        p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        return {"returncode": p.returncode, "stdout": p.stdout.strip(), "stderr": p.stderr.strip()}
    except Exception as exc:
        return {"error": repr(exc)}


def powershell_json(script: str) -> Any:
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return {"error": "PowerShell not found"}
    cmd = [ps, "-NoProfile", "-Command", script]
    out = run_cmd(cmd, timeout=30)
    if out.get("returncode") != 0:
        return out
    try:
        return json.loads(out.get("stdout") or "null")
    except Exception:
        return out


def bench_sentence_transformer(model_name: str, backend: str, device: str | None, samples: int, batch_size: int) -> Dict[str, Any]:
    try:
        from sentence_transformers import SentenceTransformer
    except Exception as exc:
        return {"ok": False, "error": f"sentence_transformers import failed: {exc}"}
    texts = [f"JOBTITLE: registered nurse EMPLOYER: hospital INDUSTRY_OTHER: health care sample {i}" for i in range(samples)]
    kwargs: Dict[str, Any] = {}
    if device:
        kwargs["device"] = device
    try:
        t0 = time.perf_counter()
        if backend in {"openvino", "onnx"}:
            model = SentenceTransformer(model_name, backend=backend, **kwargs)
        else:
            model = SentenceTransformer(model_name, **kwargs)
        load_s = time.perf_counter() - t0
        t1 = time.perf_counter()
        emb = model.encode(texts, batch_size=batch_size, show_progress_bar=False, normalize_embeddings=True, convert_to_numpy=True)
        enc_s = time.perf_counter() - t1
        return {
            "ok": True,
            "backend": backend,
            "device": device,
            "load_seconds": round(load_s, 3),
            "encode_seconds": round(enc_s, 3),
            "texts_per_second": round(samples / enc_s, 3) if enc_s > 0 else None,
            "shape": list(getattr(emb, "shape", [])),
        }
    except Exception as exc:
        return {"ok": False, "backend": backend, "device": device, "error": repr(exc)}


def bench_cross_encoder(model_name: str, backend: str, device: str | None, pairs: int, batch_size: int) -> Dict[str, Any]:
    try:
        from sentence_transformers import CrossEncoder
    except Exception as exc:
        return {"ok": False, "error": f"CrossEncoder import failed: {exc}"}
    data = [(f"survey job title registered nurse hospital sample {i}", "SOC 291141 Registered Nurses assess patient health problems and needs") for i in range(pairs)]
    kwargs: Dict[str, Any] = {}
    if device:
        kwargs["device"] = device
    try:
        t0 = time.perf_counter()
        if backend in {"openvino", "onnx"}:
            model = CrossEncoder(model_name, backend=backend, **kwargs)
        else:
            model = CrossEncoder(model_name, **kwargs)
        load_s = time.perf_counter() - t0
        t1 = time.perf_counter()
        scores = model.predict(data, batch_size=batch_size, show_progress_bar=False)
        pred_s = time.perf_counter() - t1
        return {
            "ok": True,
            "backend": backend,
            "device": device,
            "load_seconds": round(load_s, 3),
            "score_seconds": round(pred_s, 3),
            "pairs_per_second": round(pairs / pred_s, 3) if pred_s > 0 else None,
            "preview": [float(x) for x in list(scores)[:3]],
        }
    except Exception as exc:
        return {"ok": False, "backend": backend, "device": device, "error": repr(exc)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--embedding_model", default="BAAI/bge-large-en-v1.5")
    ap.add_argument("--cross_encoder_model", default="cross-encoder/ms-marco-MiniLM-L6-v2")
    ap.add_argument("--samples", type=int, default=64)
    ap.add_argument("--pairs", type=int, default=64)
    ap.add_argument("--batch_size", type=int, default=16)
    ap.add_argument("--out_json", default="C:/laborshed_autocode/gpu_acceleration_probe.json")
    ap.add_argument("--skip_model_benchmarks", action="store_true")
    args = ap.parse_args()

    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    report: Dict[str, Any] = {
        "python": sys.version,
        "platform": platform.platform(),
        "env": {k: os.environ.get(k) for k in ["CUDA_VISIBLE_DEVICES", "HF_HOME", "HF_HUB_CACHE", "OMP_NUM_THREADS", "MKL_NUM_THREADS"]},
    }

    report["windows_video_controllers"] = powershell_json("Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion,PNPDeviceID | ConvertTo-Json -Depth 3")
    report["nvidia_smi"] = run_cmd(["nvidia-smi"], timeout=20) if shutil.which("nvidia-smi") else {"found": False}

    try:
        import torch
        cuda = torch.cuda.is_available()
        report["torch"] = {
            "version": getattr(torch, "__version__", None),
            "cuda_is_available": bool(cuda),
            "cuda_version": getattr(torch.version, "cuda", None),
            "cuda_device_count": int(torch.cuda.device_count()) if cuda else 0,
            "cuda_devices": [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())] if cuda else [],
        }
    except Exception as exc:
        report["torch"] = {"error": repr(exc)}

    try:
        import torch_directml
        dml_device = torch_directml.device()
        report["torch_directml"] = {"available": True, "device": str(dml_device)}
    except Exception as exc:
        report["torch_directml"] = {"available": False, "error": repr(exc)}

    try:
        from openvino import Core
        core = Core()
        report["openvino"] = {"available": True, "devices": list(core.available_devices)}
    except Exception as exc:
        report["openvino"] = {"available": False, "error": repr(exc)}

    if not args.skip_model_benchmarks:
        benches: List[Dict[str, Any]] = []
        # CPU baseline through torch
        benches.append(bench_sentence_transformer(args.embedding_model, "torch", "cpu", args.samples, args.batch_size))
        # CUDA if available
        if report.get("torch", {}).get("cuda_is_available"):
            benches.append(bench_sentence_transformer(args.embedding_model, "torch", "cuda", args.samples, max(args.batch_size, 32)))
        # OpenVINO if installed
        if report.get("openvino", {}).get("available"):
            benches.append(bench_sentence_transformer(args.embedding_model, "openvino", None, args.samples, args.batch_size))
        report["sentence_transformer_benchmarks"] = benches

        ce_benches: List[Dict[str, Any]] = []
        ce_benches.append(bench_cross_encoder(args.cross_encoder_model, "torch", "cpu", args.pairs, args.batch_size))
        if report.get("torch", {}).get("cuda_is_available"):
            ce_benches.append(bench_cross_encoder(args.cross_encoder_model, "torch", "cuda", args.pairs, max(args.batch_size, 32)))
        if report.get("openvino", {}).get("available"):
            ce_benches.append(bench_cross_encoder(args.cross_encoder_model, "openvino", None, args.pairs, args.batch_size))
        report["cross_encoder_benchmarks"] = ce_benches

    out = Path(args.out_json)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"\nSaved: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
