#!/usr/bin/env python3
"""Pre-cache Hugging Face models used by the NAICS/SOC autocoder."""
import os
import sys

EMPTY_TOKENS = {"", '""', "''", "“”"}
tok = os.environ.get("HF_TOKEN")
if tok is not None and tok.strip() in EMPTY_TOKENS:
    os.environ.pop("HF_TOKEN", None)
    print("Removed empty/smart-quoted HF_TOKEN for this process.")

os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTHONUTF8", "1")

try:
    from sentence_transformers import SentenceTransformer, CrossEncoder
except Exception as exc:
    print(f"Could not import sentence-transformers: {exc}", file=sys.stderr)
    raise

models = [
    ("embedding", "BAAI/bge-large-en-v1.5"),
    ("cross_encoder", "cross-encoder/ms-marco-MiniLM-L6-v2"),
]

for kind, name in models:
    print(f"Caching {kind}: {name}", flush=True)
    if kind == "embedding":
        m = SentenceTransformer(name)
        _ = m.encode(["registered nurse hospital", "manufacturing plant manager"], show_progress_bar=False, normalize_embeddings=True)
    else:
        m = CrossEncoder(name)
        _ = m.predict([("registered nurse hospital", "nurse occupation healthcare")], show_progress_bar=False)
    print(f"OK: {name}", flush=True)

print("All requested models are cached.")
