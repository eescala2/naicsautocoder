param(
    [string]$Root = "C:\laborshed_autocode",
    [string]$Python = "C:\laborshed_autocode\.venv\Scripts\python.exe",
    [string]$Script = "C:\laborshed_autocode\naics_soc_ultimate_plus_stable_autocoder.py",
    [string]$TrainSav = "C:\laborshed_autocode\laborshed_train.sav",
    [string]$ScoreSav = "C:\laborshed_autocode\Statewide Q1 2026.sav",
    [string]$OutSav = "C:\laborshed_autocode\laborshed_scored.sav",
    [string]$LogTxt = "C:\laborshed_autocode\naics_soc_ultimate_plus_log.txt",
    [string]$ModelOut = "C:\laborshed_autocode\naics_soc_ultimate_plus.joblib",
    [string]$EmbeddingCacheDir = "C:\laborshed_autocode\embedding_cache",
    [string]$HfToken = "",
    [int]$MaxWorkers = 6,
    [int]$NativeThreads = 1,
    [int]$ScoreBatchSize = 2500,
    [int]$EmbeddingBatchSize = 16,
    [int]$EmbeddingChunkSize = 1024,
    [int]$EmbeddingProgressEvery = 2048
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Quote-Arg([string]$s) {
    if ($null -eq $s) { return '""' }
    return '"' + ($s -replace '"', '\"') + '"'
}

if (!(Test-Path $Root)) { New-Item -ItemType Directory -Path $Root | Out-Null }
if (!(Test-Path $Python)) { throw "Python not found: $Python" }
if (!(Test-Path $Script)) { throw "Autocoder script not found: $Script" }
if (!(Test-Path $TrainSav)) { throw "Training .sav not found: $TrainSav" }
if (!(Test-Path $ScoreSav)) { throw "Scoring .sav not found: $ScoreSav" }
if (!(Test-Path $EmbeddingCacheDir)) { New-Item -ItemType Directory -Path $EmbeddingCacheDir | Out-Null }

# Keep Windows + Python text output sane.
try { chcp 65001 | Out-Null } catch {}
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

# Keep Hugging Face models local and quiet after initial download.
$env:HF_HOME = Join-Path $Root "hf_cache"
$env:HF_HUB_CACHE = Join-Path $Root "hf_cache\hub"
$env:HF_HUB_DISABLE_PROGRESS_BARS = "1"
$env:TRANSFORMERS_NO_ADVISORY_WARNINGS = "1"

# Do not set HF_TOKEN to blank or smart quotes. That can override a valid hf auth login.
if ($HfToken.Trim().Length -gt 0) {
    $env:HF_TOKEN = $HfToken.Trim()
} elseif ($env:HF_TOKEN -eq "" -or $env:HF_TOKEN -eq "“”" -or $env:HF_TOKEN -eq '""') {
    Remove-Item Env:\HF_TOKEN -ErrorAction SilentlyContinue
}

# Avoid nested CPU thread storms.
$env:OMP_NUM_THREADS = "$NativeThreads"
$env:OPENBLAS_NUM_THREADS = "$NativeThreads"
$env:MKL_NUM_THREADS = "$NativeThreads"
$env:BLIS_NUM_THREADS = "$NativeThreads"
$env:NUMEXPR_NUM_THREADS = "$NativeThreads"
$env:TOKENIZERS_PARALLELISM = "false"

$ConsoleOut = Join-Path $Root "console_ULTIMATE_PLUS_STABLE.stdout.log"
$ConsoleErr = Join-Path $Root "console_ULTIMATE_PLUS_STABLE.stderr.log"
$Combined = Join-Path $Root "console_ULTIMATE_PLUS_STABLE.combined.log"
Remove-Item $ConsoleOut, $ConsoleErr, $Combined -ErrorAction SilentlyContinue

$argList = @(
    "-u", $Script,
    "--mode", "train_and_score",
    "--train_sav", $TrainSav,
    "--score_sav", $ScoreSav,
    "--out_sav", $OutSav,
    "--log_txt", $LogTxt,
    "--model_out", $ModelOut,
    "--save_model",
    "--profile", "accuracy",
    "--model_search", "max",
    "--use_embeddings",
    "--use_semantic_memory",
    "--use_cross_encoder_reranker",
    "--use_probability_calibration",
    "--calibration_method", "auto",
    "--semantic_backend", "auto",
    "--embedding_model", "BAAI/bge-large-en-v1.5",
    "--embedding_backend", "torch",
    "--embedding_batch_size", "$EmbeddingBatchSize",
    "--embedding_chunk_size", "$EmbeddingChunkSize",
    "--embedding_progress_every", "$EmbeddingProgressEvery",
    "--embedding_cache_dir", $EmbeddingCacheDir,
    "--cross_encoder_model", "cross-encoder/ms-marco-MiniLM-L6-v2",
    "--use_fuzzy_dictionary",
    "--max_workers", "$MaxWorkers",
    "--native_threads", "$NativeThreads",
    "--score_batch_size", "$ScoreBatchSize",
    "--ensemble_size", "3",
    "--optuna_trials_naics", "25",
    "--optuna_trials_major", "15",
    "--optuna_trials_within", "1"
)

$argString = ($argList | ForEach-Object { Quote-Arg $_ }) -join " "
Write-Host "Starting autocoder with external Python: $Python"
Write-Host "stdout log: $ConsoleOut"
Write-Host "stderr log: $ConsoleErr"
Write-Host "PowerShell NativeCommandError noise is avoided by redirecting stderr separately."

$p = Start-Process -FilePath $Python -ArgumentList $argString -RedirectStandardOutput $ConsoleOut -RedirectStandardError $ConsoleErr -PassThru -NoNewWindow
while (-not $p.HasExited) {
    Start-Sleep -Seconds 10
    if (Test-Path $ConsoleOut) {
        Write-Host "`n--- latest stdout ---"
        Get-Content $ConsoleOut -Tail 12
    }
    if (Test-Path $ConsoleErr) {
        $tailErr = Get-Content $ConsoleErr -Tail 4
        if ($tailErr) {
            Write-Host "`n--- latest stderr ---"
            $tailErr
        }
    }
}

Get-Content $ConsoleOut, $ConsoleErr -ErrorAction SilentlyContinue | Set-Content $Combined -Encoding UTF8
Write-Host "Process exit code: $($p.ExitCode)"
Write-Host "Combined log: $Combined"

if ($p.ExitCode -ne 0) {
    throw "Autocoder failed with exit code $($p.ExitCode). Check $Combined"
}

Write-Host "Done. Scored .sav: $OutSav"
Write-Host "Model bundle: $ModelOut"
