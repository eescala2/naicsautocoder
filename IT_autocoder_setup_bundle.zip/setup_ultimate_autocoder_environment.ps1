# ======================================================================
# IT setup script for the NAICS-first SOC ultimate autocoder environment.
# Run in Windows PowerShell as the user who will run the model.
# Assumes Python 3.14 64-bit is installed and available through the py launcher.
# ======================================================================

$ErrorActionPreference = "Stop"
$Root = "C:\laborshed_autocode"
$Venv = Join-Path $Root ".venv"

Write-Host "Creating project folder: $Root"
New-Item -ItemType Directory -Path $Root -Force | Out-Null

Set-Location $Root

Write-Host "Checking Python 3.14..."
py -3.14 --version
py -3.14 -c "import struct, sys; print(sys.version); print(str(8*struct.calcsize('P')) + ' bit')"

Write-Host "Creating virtual environment..."
py -3.14 -m venv $Venv

Write-Host "Activating virtual environment..."
& "$Venv\Scripts\Activate.ps1"

Write-Host "Upgrading pip/setuptools/wheel..."
python -m pip install --upgrade pip setuptools wheel

Write-Host "Installing core packages..."
python -m pip install --prefer-binary -r "$Root\requirements_naics_soc_ultimate_core.txt"

Write-Host "Trying optional SOTA packages. If one fails, install it manually or leave it out; the script falls back safely."
try {
    python -m pip install --prefer-binary -r "$Root\requirements_naics_soc_ultimate_optional.txt"
} catch {
    Write-Warning "Optional package install failed. Core autocoder can still run. Review the error above."
}

Write-Host "Verifying environment..."
python "$Root\verify_ultimate_autocoder_environment.py"

Write-Host "Pre-caching the default embedding model. This requires internet access once."
@"
from sentence_transformers import SentenceTransformer
SentenceTransformer('BAAI/bge-large-en-v1.5')
print('Embedding model cached: BAAI/bge-large-en-v1.5')
"@ | python

Write-Host "Setup complete. Virtual environment Python: $Venv\Scripts\python.exe"
