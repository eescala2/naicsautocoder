#!/usr/bin/env python3
"""Smoke-test imports for the NAICS-first SOC ultimate autocoder environment."""
from __future__ import annotations

import importlib
import os
import platform
import subprocess
import sys

CORE = [
    "numpy", "pandas", "scipy", "sklearn", "joblib", "threadpoolctl",
    "pyreadstat", "rapidfuzz", "optuna", "xgboost", "catboost",
    "sentence_transformers", "torch", "transformers", "openpyxl", "psutil",
]
OPTIONAL = ["lightgbm", "faiss", "llama_cpp", "openvino", "onnxruntime"]

print("Python:", sys.version)
print("Executable:", sys.executable)
print("Platform:", platform.platform())
print("CPU logical cores:", os.cpu_count())
print()

failed_core = []
for name in CORE:
    try:
        mod = importlib.import_module(name)
        version = getattr(mod, "__version__", "unknown")
        print("CORE OK      {0:24s} {1}".format(name, version))
    except Exception as exc:
        print("CORE FAIL    {0:24s} {1}".format(name, exc))
        failed_core.append(name)

print()
for name in OPTIONAL:
    try:
        mod = importlib.import_module(name)
        version = getattr(mod, "__version__", "unknown")
        print("OPTIONAL OK  {0:24s} {1}".format(name, version))
    except Exception as exc:
        print("OPTIONAL SKIP {0:24s} {1}".format(name, exc))

print()
script = os.path.join(os.getcwd(), "naics_soc_ultimate_autocoder.py")
if os.path.exists(script):
    result = subprocess.run([sys.executable, script, "--help"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print("Autocoder --help exit code:", result.returncode)
    if result.returncode != 0:
        print(result.stdout[:2000])
else:
    print("Autocoder script not found in current directory:", script)

if failed_core:
    raise SystemExit("Missing required packages: " + ", ".join(failed_core))
print("Environment verification complete.")
