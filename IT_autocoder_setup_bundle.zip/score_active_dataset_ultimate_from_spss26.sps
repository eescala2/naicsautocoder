* ======================================================================
* SPSS 26 launcher: score the ACTIVE dataset with the trained autocoder.
*
* Workflow:
* 1. Open the .sav file you want to score in SPSS.
* 2. Run this syntax.
* 3. SPSS saves the active dataset to a temporary .sav.
* 4. External Python 3.14 scores it.
* 5. SPSS opens the scored .sav so you can edit it normally.
*
* IMPORTANT:
* - Edit ROOT, PYTHON_EXE, SCRIPT, MODEL_IN, OUT_SAV, LOG_TXT, and CONSOLE_LOG.
* - This uses SPSS's Python 3.4 only as a launcher, so do not import pandas,
*   sklearn, pyreadstat, torch, etc. here.
* ======================================================================.

SET MPRINT=YES.

* Save the currently open SPSS dataset as the input file for Python scoring.
SAVE OUTFILE='C:\laborshed_autocode\_spss_active_input_to_score.sav'
  /COMPRESSED.
EXECUTE.

BEGIN PROGRAM PYTHON3.
import os
import subprocess
import sys

ROOT = r"C:\laborshed_autocode"
PYTHON_EXE = r"C:\laborshed_autocode\.venv\Scripts\python.exe"
SCRIPT = r"C:\laborshed_autocode\naics_soc_ultimate_autocoder.py"
MODEL_IN = r"C:\laborshed_autocode\naics_soc_ultimate.joblib"
SCORE_SAV = r"C:\laborshed_autocode\_spss_active_input_to_score.sav"
OUT_SAV = r"C:\laborshed_autocode\_spss_active_scored_output.sav"
LOG_TXT = r"C:\laborshed_autocode\naics_soc_ultimate_score_log.txt"
CONSOLE_LOG = r"C:\laborshed_autocode\console_score_active_from_spss.log"

# Safety thread settings for laptop use. The external script also enforces these.
env = os.environ.copy()
for key in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
    env[key] = "1"
env["TOKENIZERS_PARALLELISM"] = "false"

cmd = [
    PYTHON_EXE,
    "-u",
    SCRIPT,
    "--mode", "score",
    "--model_in", MODEL_IN,
    "--score_sav", SCORE_SAV,
    "--out_sav", OUT_SAV,
    "--log_txt", LOG_TXT,
    "--max_workers", "6",
    "--native_threads", "1",
    "--score_batch_size", "2500"
]

for path, label in [(PYTHON_EXE, "Python executable"), (SCRIPT, "autocoder script"), (MODEL_IN, "trained model"), (SCORE_SAV, "input SAV")]:
    if not os.path.exists(path):
        raise RuntimeError(label + " not found: " + path)

log_dir = os.path.dirname(CONSOLE_LOG)
if log_dir and not os.path.exists(log_dir):
    os.makedirs(log_dir)

with open(CONSOLE_LOG, "w") as log:
    log.write("External Python command:\n")
    log.write(" ".join(['\"' + x + '\"' if " " in x else x for x in cmd]) + "\n\n")
    process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env)
    return_code = process.wait()

if return_code != 0:
    raise RuntimeError("Autocoder failed with exit code " + str(return_code) + ". See " + CONSOLE_LOG)

if not os.path.exists(OUT_SAV):
    raise RuntimeError("Autocoder finished but output SAV was not found: " + OUT_SAV)

print("Autocoder complete. Console log: " + CONSOLE_LOG)
print("Scored SAV: " + OUT_SAV)
END PROGRAM.

* Load the scored file into SPSS. It is now a normal editable SPSS dataset.
GET FILE='C:\laborshed_autocode\_spss_active_scored_output.sav'.
DATASET NAME AutocodedData WINDOW=FRONT.
EXECUTE.

* Optional: save a named reusable copy immediately. You can also comment this out,
* edit first in Data View/Variable View, then use File > Save As.
SAVE OUTFILE='C:\laborshed_autocode\laborshed_scored_from_spss.sav'
  /COMPRESSED.
EXECUTE.
