* ======================================================================
* SPSS 26 launcher: train the model, score a named .sav, and open output.
*
* Use this when you want SPSS to launch the initial training run.
* For routine future scoring, use score_active_dataset_ultimate_from_spss26.sps.
*
* IMPORTANT:
* - This can take a long time.
* - It saves a reusable trained model: C:\laborshed_autocode\naics_soc_ultimate.joblib
* - SPSS Python 3.4 is used only as a launcher for external Python 3.14.
* ======================================================================.

SET MPRINT=YES.

BEGIN PROGRAM PYTHON3.
import os
import subprocess
import sys

ROOT = r"C:\laborshed_autocode"
PYTHON_EXE = r"C:\laborshed_autocode\.venv\Scripts\python.exe"
SCRIPT = r"C:\laborshed_autocode\naics_soc_ultimate_autocoder.py"
TRAIN_SAV = r"C:\laborshed_autocode\laborshed_train.sav"
SCORE_SAV = r"C:\laborshed_autocode\laborshed_to_score.sav"
OUT_SAV = r"C:\laborshed_autocode\laborshed_scored.sav"
LOG_TXT = r"C:\laborshed_autocode\naics_soc_ultimate_log.txt"
MODEL_OUT = r"C:\laborshed_autocode\naics_soc_ultimate.joblib"
CONSOLE_LOG = r"C:\laborshed_autocode\console_train_and_score_from_spss.log"

# Safety thread settings for laptop use. The external script also enforces these.
env = os.environ.copy()
for key in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
    env[key] = "1"
env["TOKENIZERS_PARALLELISM"] = "false"

cmd = [
    PYTHON_EXE,
    "-u",
    SCRIPT,
    "--mode", "train_and_score",
    "--train_sav", TRAIN_SAV,
    "--score_sav", SCORE_SAV,
    "--out_sav", OUT_SAV,
    "--log_txt", LOG_TXT,
    "--model_out", MODEL_OUT,
    "--save_model",
    "--profile", "accuracy",
    "--model_search", "max",
    "--use_embeddings",
    "--use_semantic_memory",
    "--semantic_backend", "auto",
    "--embedding_model", "BAAI/bge-large-en-v1.5",
    "--embedding_backend", "torch",
    "--use_fuzzy_dictionary",
    "--max_workers", "6",
    "--native_threads", "1",
    "--score_batch_size", "2500",
    "--ensemble_size", "3",
    "--optuna_trials_naics", "25",
    "--optuna_trials_major", "15",
    "--optuna_trials_within", "1"
]

for path, label in [(PYTHON_EXE, "Python executable"), (SCRIPT, "autocoder script"), (TRAIN_SAV, "training SAV"), (SCORE_SAV, "scoring SAV")]:
    if not os.path.exists(path):
        raise RuntimeError(label + " not found: " + path)

log_dir = os.path.dirname(CONSOLE_LOG)
if log_dir and not os.path.exists(log_dir):
    os.makedirs(log_dir)

with open(CONSOLE_LOG, "w") as log:
    log.write("External Python command:\n")
    log.write(" ".join(['\"' + x + '\"' if " " in x else x for x in cmd]) + "\n\n")
    process = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env)
    return_code = process.wait()

if return_code != 0:
    raise RuntimeError("Autocoder failed with exit code " + str(return_code) + ". See " + CONSOLE_LOG)

if not os.path.exists(OUT_SAV):
    raise RuntimeError("Autocoder finished but output SAV was not found: " + OUT_SAV)

print("Autocoder complete. Console log: " + CONSOLE_LOG)
print("Scored SAV: " + OUT_SAV)
print("Reusable model: " + MODEL_OUT)
END PROGRAM.

GET FILE='C:\laborshed_autocode\laborshed_scored.sav'.
DATASET NAME AutocodedData WINDOW=FRONT.
EXECUTE.
