cd C:\laborshed_autocode
.\.venv\Scripts\Activate.ps1

$env:PYTHONUTF8="1"
$env:PYTHONIOENCODING="utf-8"
$env:HF_HUB_OFFLINE="1"
$env:TRANSFORMERS_OFFLINE="1"
$env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"
$env:OMP_NUM_THREADS="1"
$env:OPENBLAS_NUM_THREADS="1"
$env:MKL_NUM_THREADS="1"
$env:BLIS_NUM_THREADS="1"
$env:NUMEXPR_NUM_THREADS="1"
$env:TOKENIZERS_PARALLELISM="false"

.\.venv\Scripts\python.exe -u .\naics_soc_laptop_tuned_fullfill_autocoder.py `
  --mode train_and_score `
  --train_sav "C:\laborshed_autocode\laborshed_train.sav" `
  --score_sav "C:\laborshed_autocode\Statewide Q1 2026.sav" `
  --out_sav "C:\laborshed_autocode\laborshed_scored_gpu_lane3_FULLFILL.sav" `
  --log_txt "C:\laborshed_autocode\naics_soc_gpu_lane3_FULLFILL_log.txt" `
  --model_out "C:\laborshed_autocode\naics_soc_gpu_lane3_FULLFILL.joblib" `
  --save_model `
  --profile accuracy `
  --model_search robust `
  --candidate_models "sgd,linear_svc,complement_nb,lightgbm" `
  --use_embeddings `
  --use_semantic_memory `
  --semantic_backend faiss `
  --embedding_model "BAAI/bge-large-en-v1.5" `
  --embedding_backend torch `
  --embedding_device cuda `
  --embedding_batch_size 16 `
  --embedding_chunk_size 2048 `
  --embedding_progress_every 2048 `
  --embedding_cache_dir "C:\laborshed_autocode\embedding_cache" `
  --use_fuzzy_dictionary `
  --use_cross_encoder_reranker `
  --cross_encoder_model "cross-encoder/ms-marco-MiniLM-L6-v2" `
  --cross_encoder_batch_size 32 `
  --cross_encoder_topn 8 `
  --fill_all_missing `
  --max_workers 6 `
  --native_threads 1 `
  --score_batch_size 1500 `
  --ensemble_size 1 `
  --nfolds_naics 3 `
  --nfolds_major 3 `
  --nfolds_within 2 `
  --boost_n_estimators 180 `
  --optuna_trials_naics 0 `
  --optuna_trials_major 0 `
  --optuna_trials_within 0 `
  --joblib_compress 0 `
  --console_log "C:\laborshed_autocode\console_LANE3_FULLFILL_live.log"
