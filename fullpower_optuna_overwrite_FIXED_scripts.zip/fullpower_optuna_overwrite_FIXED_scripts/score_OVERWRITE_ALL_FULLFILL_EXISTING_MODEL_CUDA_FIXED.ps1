# Score-only overwrite/full-fill run using an existing trained model.
# Optuna is not used in score mode because the model is already trained.
# Run from Positron Terminal with:
#   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#   cd C:\laborshed_autocode
#   .\score_OVERWRITE_ALL_FULLFILL_EXISTING_MODEL_CUDA.ps1

cd C:\laborshed_autocode
.\.venv\Scripts\Activate.ps1

$env:PYTHONUTF8="1"
$env:PYTHONIOENCODING="utf-8"
$env:HF_HOME="C:\laborshed_autocode\hf_cache"
$env:HF_HUB_CACHE="C:\laborshed_autocode\hf_cache\hub"
$env:HF_HUB_OFFLINE="1"
$env:TRANSFORMERS_OFFLINE="1"
$env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"
$env:OMP_NUM_THREADS="1"
$env:OPENBLAS_NUM_THREADS="1"
$env:MKL_NUM_THREADS="1"
$env:BLIS_NUM_THREADS="1"
$env:NUMEXPR_NUM_THREADS="1"
$env:TOKENIZERS_PARALLELISM="false"

.\.venv\Scripts\python.exe -u .\naics_soc_laptop_tuned_fullfill_autocoder_OPTUNA_FIX.py `
  --mode score `
  --model_in "C:\laborshed_autocode\naics_soc_gpu_lane1.joblib" `
  --score_sav "C:\laborshed_autocode\Statewide Q1 2026.sav" `
  --out_sav "C:\laborshed_autocode\laborshed_scored_OVERWRITE_FULLFILL.sav" `
  --log_txt "C:\laborshed_autocode\naics_soc_OVERWRITE_FULLFILL_log.txt" `
  --fill_all_missing `
  --score_rows_without_text `
  --fallback_fill_missing `
  --overwrite_existing `
  --embedding_device cuda `
  --embedding_batch_size 16 `
  --embedding_cache_dir "C:\laborshed_autocode\embedding_cache" `
  --max_workers 6 `
  --native_threads 1 `
  --score_batch_size 1500 `
  --console_log "C:\laborshed_autocode\console_OVERWRITE_FULLFILL_live.log"
