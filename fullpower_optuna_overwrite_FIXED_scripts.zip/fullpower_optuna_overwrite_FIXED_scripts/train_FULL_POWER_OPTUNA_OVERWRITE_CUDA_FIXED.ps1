# Full-power CUDA + Optuna train-and-score run for NAICS-first SOC autocoder.
# Run from Positron Terminal with:
#   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#   cd C:\laborshed_autocode
#   .\train_FULL_POWER_OPTUNA_OVERWRITE_CUDA.ps1

cd C:\laborshed_autocode
.\.venv\Scripts\Activate.ps1

# Keep Hugging Face offline once models are cached, so the run cannot crash midstream on internet HEAD requests.
$env:PYTHONUTF8="1"
$env:PYTHONIOENCODING="utf-8"
$env:HF_HOME="C:\laborshed_autocode\hf_cache"
$env:HF_HUB_CACHE="C:\laborshed_autocode\hf_cache\hub"
$env:HF_HUB_OFFLINE="1"
$env:TRANSFORMERS_OFFLINE="1"
$env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:CUDA_VISIBLE_DEVICES="0"
$env:OMP_NUM_THREADS="1"
$env:OPENBLAS_NUM_THREADS="1"
$env:MKL_NUM_THREADS="1"
$env:BLIS_NUM_THREADS="1"
$env:NUMEXPR_NUM_THREADS="1"
$env:TOKENIZERS_PARALLELISM="false"

.\.venv\Scripts\python.exe -u .\naics_soc_laptop_tuned_fullfill_autocoder_OPTUNA_FIX.py `
  --mode train_and_score `
  --train_sav "C:\laborshed_autocode\laborshed_train.sav" `
  --score_sav "C:\laborshed_autocode\Statewide Q1 2026.sav" `
  --out_sav "C:\laborshed_autocode\laborshed_scored_FULLPOWER_OPTUNA_OVERWRITE.sav" `
  --log_txt "C:\laborshed_autocode\naics_soc_FULLPOWER_OPTUNA_OVERWRITE_log.txt" `
  --model_out "C:\laborshed_autocode\naics_soc_FULLPOWER_OPTUNA_OVERWRITE.joblib" `
  --save_model `
  --profile accuracy `
  --model_search max `
  --candidate_models "sgd,linear_svc,complement_nb,lightgbm,xgboost,catboost" `
  --use_embeddings `
  --use_semantic_memory `
  --semantic_backend faiss `
  --embedding_model "BAAI/bge-large-en-v1.5" `
  --embedding_backend torch `
  --embedding_device cuda `
  --embedding_batch_size 16 `
  --embedding_chunk_size 2048 `
  --embedding_progress_every 2048 `
  --embedding_cache_dir "C:\laborshed_autocode\embedding_cache" `
  --use_fuzzy_dictionary `
  --use_cross_encoder_reranker `
  --cross_encoder_model "cross-encoder/ms-marco-MiniLM-L6-v2" `
  --cross_encoder_batch_size 32 `
  --cross_encoder_topn 8 `
  --cross_encoder_fusion_weight 0.75 `
  --use_probability_calibration `
  --calibration_method auto `
  --fill_all_missing `
  --score_rows_without_text `
  --fallback_fill_missing `
  --overwrite_existing `
  --max_workers 6 `
  --native_threads 1 `
  --score_batch_size 1500 `
  --ensemble_size 1 `
  --nfolds_naics 3 `
  --nfolds_major 3 `
  --nfolds_within 2 `
  --boost_n_estimators 220 `
  --optuna_trials_naics 8 `
  --optuna_trials_major 5 `
  --optuna_trials_within 1 `
  --joblib_compress 0 `
  --console_log "C:\laborshed_autocode\console_FULLPOWER_OPTUNA_OVERWRITE_live.log"
