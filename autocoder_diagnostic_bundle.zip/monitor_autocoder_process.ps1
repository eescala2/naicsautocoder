<#
Monitor a running NAICS/SOC autocoder process.
Run in a separate Positron or Windows Terminal window.
#>
param(
    [int]$Seconds = 300,
    [string]$ProjectDir = "C:\laborshed_autocode",
    [string]$ScriptPattern = "naics_soc_ultimate_plus_stable_autocoder.py"
)

Write-Host "Finding autocoder python processes..." -ForegroundColor Cyan
$procs = Get-CimInstance Win32_Process |
    Where-Object { $_.Name -like "python*" -and $_.CommandLine -like "*$ScriptPattern*" } |
    Select-Object ProcessId, ParentProcessId, CreationDate, CommandLine

if (-not $procs) {
    Write-Host "No autocoder process found for pattern: $ScriptPattern" -ForegroundColor Yellow
} else {
    $procs | Format-List
    if (($procs | Measure-Object).Count -gt 1) {
        Write-Host "WARNING: More than one autocoder process is running. Stop duplicates before continuing." -ForegroundColor Red
    }
}

$ids = @($procs | ForEach-Object { $_.ProcessId })
if ($ids.Count -gt 0) {
    Write-Host "Measuring CPU/RAM for $Seconds seconds..." -ForegroundColor Cyan
    $before = Get-Process -Id $ids -ErrorAction SilentlyContinue
    Start-Sleep -Seconds $Seconds
    $after = Get-Process -Id $ids -ErrorAction SilentlyContinue
    foreach ($p in $after) {
        $b = $before | Where-Object { $_.Id -eq $p.Id }
        [pscustomobject]@{
            Id = $p.Id
            CPU_Seconds_Added = [math]::Round($p.CPU - $b.CPU, 1)
            RAM_GB = [math]::Round($p.WorkingSet64 / 1GB, 2)
            StartTime = $p.StartTime
            Path = $p.Path
        }
    }
}

Write-Host "Recent project files:" -ForegroundColor Cyan
Get-ChildItem $ProjectDir -File -Recurse |
  Where-Object { $_.Name -match "ultimate|scored|console|stdout|stderr|\.joblib$|\.json$|\.sav$|\.log$|\.npy$" } |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 50 LastWriteTime,
    @{Name="MB";Expression={[math]::Round($_.Length / 1MB, 2)}},
    FullName |
  Format-Table -AutoSize

Write-Host "Recent log milestones/errors:" -ForegroundColor Cyan
$logs = Get-ChildItem $ProjectDir -File -Include *.log,*.txt -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.Length -lt 200MB }
if ($logs) {
    Select-String -Path ($logs.FullName) -Pattern "Selected model|Training SOC|Training NAICS|Scoring|Writing|Done|Traceback|ERROR|failed|CV candidate|macro-F1|Semantic-memory|Feature matrix" -ErrorAction SilentlyContinue |
        Select-Object -Last 120 |
        Format-List
}
