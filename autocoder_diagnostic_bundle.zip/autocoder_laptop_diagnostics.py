#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Autocoder laptop diagnostics for NAICS/SOC pipeline.
Run from the same virtual environment as the autocoder.
It does NOT train the full model. It measures the environment, package imports,
SPSS file sizes/metadata, embedding throughput, FAISS availability, and thread pools.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import platform
import shutil
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# Make defaults safe before importing numeric libraries.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("BLIS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")


def now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def version_or_error(module_name: str) -> Dict[str, Any]:
    try:
        mod = __import__(module_name)
        return {"available": True, "version": getattr(mod, "__version__", "unknown"), "error": ""}
    except Exception as exc:
        return {"available": False, "version": None, "error": str(exc)[:500]}


def safe_gb(n: Optional[int]) -> Optional[float]:
    if n is None:
        return None
    return round(float(n) / (1024 ** 3), 2)


def disk_info(path: str) -> Dict[str, Any]:
    p = Path(path).resolve()
    target = str(p if p.exists() else p.parent if p.parent.exists() else Path.cwd())
    total, used, free = shutil.disk_usage(target)
    return {"path_checked": target, "total_gb": safe_gb(total), "used_gb": safe_gb(used), "free_gb": safe_gb(free)}


def psutil_info() -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    try:
        import psutil  # type: ignore
        vm = psutil.virtual_memory()
        out.update({
            "available": True,
            "physical_cores": psutil.cpu_count(logical=False),
            "logical_cpus": psutil.cpu_count(logical=True),
            "memory_total_gb": safe_gb(vm.total),
            "memory_available_gb": safe_gb(vm.available),
            "memory_percent_used": vm.percent,
            "cpu_freq": psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None,
        })
    except Exception as exc:
        out.update({"available": False, "error": str(exc)[:500], "logical_cpus": os.cpu_count()})
    return out


def read_sav_metadata(path: str, sample_rows: int, columns: Optional[List[str]] = None) -> Dict[str, Any]:
    out: Dict[str, Any] = {"path": path, "exists": Path(path).exists()}
    if not out["exists"]:
        return out
    out["file_size_gb"] = round(Path(path).stat().st_size / (1024 ** 3), 3)
    try:
        import pyreadstat  # type: ignore
        t0 = time.perf_counter()
        df_meta, meta = pyreadstat.read_sav(path, metadataonly=True, user_missing=True, apply_value_formats=False)
        out["metadata_seconds"] = round(time.perf_counter() - t0, 3)
        out["n_columns"] = len(getattr(meta, "column_names", []) or [])
        out["n_rows_reported"] = getattr(meta, "number_rows", None)
        out["columns_preview"] = list((getattr(meta, "column_names", []) or [])[:30])
        # Read a small sample so we can confirm real loading speed and create text samples.
        read_kwargs: Dict[str, Any] = dict(user_missing=True, apply_value_formats=False, row_limit=max(1, sample_rows))
        if columns:
            # pyreadstat versions vary; usecols may not exist in old builds.
            try:
                read_kwargs["usecols"] = [c for c in columns if c in (getattr(meta, "column_names", []) or [])]
            except Exception:
                pass
        t1 = time.perf_counter()
        try:
            df_sample, _ = pyreadstat.read_sav(path, **read_kwargs)
        except TypeError:
            read_kwargs.pop("usecols", None)
            df_sample, _ = pyreadstat.read_sav(path, **read_kwargs)
        out["sample_read_seconds"] = round(time.perf_counter() - t1, 3)
        out["sample_rows_read"] = int(len(df_sample))
        out["sample_columns_read"] = int(len(df_sample.columns))
        out["sample_memory_mb"] = round(df_sample.memory_usage(deep=True).sum() / (1024 ** 2), 2)
        out["sample_columns"] = list(df_sample.columns[:50])
    except Exception as exc:
        out["error"] = str(exc)[:1000]
    return out


def make_sample_docs_from_sav(path: str, sample_rows: int) -> List[str]:
    cols = ["qe4", "qe5a", "qa20", "qa20a", "qe1oth", "qe8aoth", "qe2b", "qa9a", "qa9g", "qe13oth"]
    try:
        import pandas as pd  # noqa
        import pyreadstat  # type: ignore
        try:
            df, _ = pyreadstat.read_sav(path, user_missing=True, apply_value_formats=False, row_limit=max(1, sample_rows), usecols=cols)
        except Exception:
            df, _ = pyreadstat.read_sav(path, user_missing=True, apply_value_formats=False, row_limit=max(1, sample_rows))
        existing = [c for c in cols if c in df.columns]
        if not existing:
            return ["sample job title employer industry"] * sample_rows
        docs: List[str] = []
        for _, row in df[existing].iterrows():
            parts = []
            for c in existing:
                v = row.get(c)
                if v is None:
                    continue
                s = str(v).strip()
                if s and s.lower() != "nan":
                    parts.append(f"{c}: {s}")
            docs.append(" | ".join(parts) if parts else "sample job title employer industry")
        return docs or ["sample job title employer industry"] * sample_rows
    except Exception:
        return [
            "jobtitle: office manager | employer: regional hospital | industry: healthcare",
            "jobtitle: welder fabricator | employer: metal fabrication plant | industry: manufacturing",
            "jobtitle: registered nurse | employer: clinic | industry: healthcare",
            "jobtitle: truck driver cdl | employer: logistics company | industry: transportation",
        ] * max(1, sample_rows // 4)


def embedding_benchmark(model_name: str, backend: str, docs: List[str], batch_sizes: List[int], cache_dir: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {"model": model_name, "backend": backend, "n_docs": len(docs), "batch_results": []}
    try:
        from sentence_transformers import SentenceTransformer  # type: ignore
        kwargs: Dict[str, Any] = {}
        if backend and backend != "torch":
            kwargs["backend"] = backend
        t_load = time.perf_counter()
        model = SentenceTransformer(model_name, **kwargs)
        out["load_seconds"] = round(time.perf_counter() - t_load, 3)
        # Warm-up.
        _ = model.encode(docs[: min(8, len(docs))], batch_size=min(8, max(1, len(docs))), show_progress_bar=False, normalize_embeddings=True, convert_to_numpy=True)
        for bs in batch_sizes:
            bs = max(1, int(bs))
            t0 = time.perf_counter()
            emb = model.encode(docs, batch_size=bs, show_progress_bar=False, normalize_embeddings=True, convert_to_numpy=True)
            sec = time.perf_counter() - t0
            out["batch_results"].append({
                "batch_size": bs,
                "seconds": round(sec, 3),
                "texts_per_second": round(len(docs) / sec, 3) if sec > 0 else None,
                "embedding_shape": list(emb.shape),
                "embedding_mb": round(emb.nbytes / (1024 ** 2), 2),
            })
        try:
            import torch  # type: ignore
            out["torch_num_threads"] = torch.get_num_threads()
            out["torch_num_interop_threads"] = torch.get_num_interop_threads()
        except Exception:
            pass
    except Exception as exc:
        out["error"] = str(exc)[:2000]
    return out


def cross_encoder_benchmark(model_name: str, docs: List[str], n_pairs: int) -> Dict[str, Any]:
    out: Dict[str, Any] = {"model": model_name, "n_pairs": n_pairs}
    try:
        from sentence_transformers import CrossEncoder  # type: ignore
        pairs = []
        base = docs[: max(2, min(len(docs), n_pairs))]
        for i in range(n_pairs):
            a = base[i % len(base)]
            b = base[(i * 7 + 3) % len(base)]
            pairs.append((a, b))
        t_load = time.perf_counter()
        model = CrossEncoder(model_name)
        out["load_seconds"] = round(time.perf_counter() - t_load, 3)
        _ = model.predict(pairs[: min(4, len(pairs))], show_progress_bar=False)
        t0 = time.perf_counter()
        scores = model.predict(pairs, show_progress_bar=False)
        sec = time.perf_counter() - t0
        out.update({
            "seconds": round(sec, 3),
            "pairs_per_second": round(len(pairs) / sec, 3) if sec > 0 else None,
            "score_preview": [float(x) for x in list(scores[:5])],
        })
    except Exception as exc:
        out["error"] = str(exc)[:2000]
    return out


def faiss_benchmark(n_vectors: int, dim: int, k: int) -> Dict[str, Any]:
    out: Dict[str, Any] = {"n_vectors": n_vectors, "dim": dim, "k": k}
    try:
        import numpy as np
        import faiss  # type: ignore
        rng = np.random.default_rng(42)
        xb = rng.normal(size=(n_vectors, dim)).astype("float32")
        xb /= np.linalg.norm(xb, axis=1, keepdims=True) + 1e-12
        xq = xb[: min(256, n_vectors)].copy()
        t0 = time.perf_counter()
        index = faiss.IndexFlatIP(dim)
        index.add(xb)
        out["index_seconds"] = round(time.perf_counter() - t0, 3)
        t1 = time.perf_counter()
        d, i = index.search(xq, k)
        sec = time.perf_counter() - t1
        out.update({"search_seconds": round(sec, 3), "queries_per_second": round(len(xq) / sec, 2) if sec > 0 else None, "backend": "faiss.IndexFlatIP"})
    except Exception as exc:
        out["error"] = str(exc)[:2000]
    return out


def sklearn_sparse_benchmark(n_rows: int, n_features: int, n_classes: int, density: float) -> Dict[str, Any]:
    out: Dict[str, Any] = {"n_rows": n_rows, "n_features": n_features, "n_classes": n_classes, "density": density}
    try:
        import numpy as np
        import scipy.sparse as sp
        from sklearn.linear_model import SGDClassifier
        from sklearn.metrics import f1_score
        from sklearn.model_selection import train_test_split
        rng = np.random.default_rng(42)
        nnz = int(n_rows * n_features * density)
        row = rng.integers(0, n_rows, size=nnz, endpoint=False)
        col = rng.integers(0, n_features, size=nnz, endpoint=False)
        data = rng.random(nnz, dtype=np.float32)
        X = sp.csr_matrix((data, (row, col)), shape=(n_rows, n_features), dtype=np.float32)
        y = rng.integers(0, n_classes, size=n_rows, endpoint=False)
        Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
        clf = SGDClassifier(loss="log_loss", penalty="elasticnet", alpha=1e-5, l1_ratio=0.15, max_iter=300, tol=1e-3, random_state=42)
        t0 = time.perf_counter()
        clf.fit(Xtr, ytr)
        fit_sec = time.perf_counter() - t0
        t1 = time.perf_counter()
        pred = clf.predict(Xte)
        pred_sec = time.perf_counter() - t1
        out.update({
            "fit_seconds": round(fit_sec, 3),
            "predict_seconds": round(pred_sec, 3),
            "macro_f1_synthetic": round(float(f1_score(yte, pred, average="macro", zero_division=0)), 4),
            "matrix_nnz": int(X.nnz),
            "matrix_mb": round((X.data.nbytes + X.indices.nbytes + X.indptr.nbytes) / (1024 ** 2), 2),
        })
    except Exception as exc:
        out["error"] = str(exc)[:2000]
    return out


def recommend(result: Dict[str, Any]) -> List[str]:
    rec: List[str] = []
    ps = result.get("system", {}).get("psutil", {})
    cpus = ps.get("logical_cpus") or os.cpu_count() or 1
    mem = ps.get("memory_total_gb") or 0
    rec.append("Use exactly one autocoder process at a time. Confirm with Get-CimInstance before starting a run.")
    if cpus >= 18 and mem >= 60:
        rec.append("Laptop-safe default: --max_workers 6 --native_threads 1. Avoid 12×4 or any setting that multiplies above the logical CPU count.")
    else:
        rec.append("Use --max_workers 4 --native_threads 1 as a safer default on this machine.")
    emb = result.get("embedding_benchmark", {}).get("batch_results", [])
    if emb:
        best = max([x for x in emb if x.get("texts_per_second")], key=lambda x: x["texts_per_second"], default=None)
        if best:
            rec.append(f"Best measured embedding batch size: {best['batch_size']} ({best['texts_per_second']} texts/sec on sample).")
            if best["texts_per_second"] < 3:
                rec.append("BGE-large CPU embedding is very slow here. Use cached embeddings, or consider BAAI/bge-base-en-v1.5 for faster iteration.")
    if not result.get("package_versions", {}).get("faiss", {}).get("available"):
        rec.append("FAISS is missing. Install faiss-cpu if possible; otherwise semantic retrieval will be much slower.")
    if result.get("package_versions", {}).get("lightgbm", {}).get("available"):
        rec.append("LightGBM is available. Robust profile can use it without enabling the full max/Optuna search.")
    rec.append("For the next full run, start with: --model_search robust --ensemble_size 1 --nfolds_naics 3 --nfolds_major 3 --nfolds_within 2 --optuna_trials_* 0.")
    rec.append("After a successful baseline, evaluate accuracy. Only then add cross-encoder reranking, calibration, or limited Optuna trials.")
    return rec


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--train_sav", default=r"C:\laborshed_autocode\laborshed_train.sav")
    ap.add_argument("--score_sav", default=r"C:\laborshed_autocode\Statewide Q1 2026.sav")
    ap.add_argument("--out_json", default=r"C:\laborshed_autocode\diagnostics_autocoder_laptop.json")
    ap.add_argument("--out_txt", default=r"C:\laborshed_autocode\diagnostics_autocoder_laptop.txt")
    ap.add_argument("--sample_rows", type=int, default=512)
    ap.add_argument("--embedding_model", default="BAAI/bge-large-en-v1.5")
    ap.add_argument("--embedding_backend", default="torch")
    ap.add_argument("--embedding_batch_sizes", default="8,16,32")
    ap.add_argument("--cross_encoder_model", default="cross-encoder/ms-marco-MiniLM-L6-v2")
    ap.add_argument("--cross_encoder_pairs", type=int, default=64)
    ap.add_argument("--embedding_cache_dir", default=r"C:\laborshed_autocode\embedding_cache")
    ap.add_argument("--skip_embedding_benchmark", action="store_true")
    ap.add_argument("--skip_cross_encoder_benchmark", action="store_true")
    args = ap.parse_args()

    t_all = time.perf_counter()
    result: Dict[str, Any] = {
        "created_at": now(),
        "python": sys.version,
        "executable": sys.executable,
        "platform": platform.platform(),
        "cwd": os.getcwd(),
        "env_thread_vars": {k: os.environ.get(k) for k in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "TOKENIZERS_PARALLELISM", "HF_HOME", "HF_HUB_CACHE", "HF_HUB_DISABLE_PROGRESS_BARS"]},
    }

    result["system"] = {"psutil": psutil_info(), "disk_project": disk_info(r"C:\laborshed_autocode")}
    packages = ["numpy", "pandas", "scipy", "sklearn", "pyreadstat", "joblib", "threadpoolctl", "psutil", "sentence_transformers", "torch", "faiss", "lightgbm", "xgboost", "catboost", "optuna", "rapidfuzz", "llama_cpp"]
    result["package_versions"] = {p: version_or_error(p) for p in packages}
    try:
        from threadpoolctl import threadpool_info  # type: ignore
        result["threadpool_info"] = threadpool_info()
    except Exception as exc:
        result["threadpool_info_error"] = str(exc)[:500]

    columns = ["id", "qa20a", "qe4", "qe4ar", "qe5a", "qe5ar", "qa20", "qe1oth", "qe8aoth", "qe10"]
    result["train_sav"] = read_sav_metadata(args.train_sav, args.sample_rows, columns)
    result["score_sav"] = read_sav_metadata(args.score_sav, args.sample_rows, columns)

    docs = make_sample_docs_from_sav(args.train_sav, args.sample_rows)
    result["sample_docs"] = {"n_docs": len(docs), "first_doc_preview": docs[0][:300] if docs else ""}

    if not args.skip_embedding_benchmark:
        batch_sizes = [int(x.strip()) for x in args.embedding_batch_sizes.split(",") if x.strip()]
        result["embedding_benchmark"] = embedding_benchmark(args.embedding_model, args.embedding_backend, docs, batch_sizes, args.embedding_cache_dir)
    else:
        result["embedding_benchmark"] = {"skipped": True}

    if not args.skip_cross_encoder_benchmark:
        result["cross_encoder_benchmark"] = cross_encoder_benchmark(args.cross_encoder_model, docs, args.cross_encoder_pairs)
    else:
        result["cross_encoder_benchmark"] = {"skipped": True}

    result["faiss_benchmark"] = faiss_benchmark(n_vectors=20000, dim=1024, k=10)
    result["sparse_sgd_benchmark"] = sklearn_sparse_benchmark(n_rows=12000, n_features=30000, n_classes=80, density=0.0015)
    result["total_seconds"] = round(time.perf_counter() - t_all, 3)
    result["recommendations"] = recommend(result)

    Path(args.out_json).write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")

    lines: List[str] = []
    lines.append("AUTOCODER LAPTOP DIAGNOSTICS")
    lines.append("============================")
    lines.append(f"Created: {result['created_at']}")
    lines.append(f"Python: {sys.executable}")
    lines.append(f"Platform: {result['platform']}")
    lines.append("")
    lines.append("System:")
    lines.append(json.dumps(result["system"], indent=2, default=str))
    lines.append("")
    lines.append("Packages:")
    for k, v in result["package_versions"].items():
        lines.append(f"  {k}: {'OK ' + str(v.get('version')) if v.get('available') else 'MISSING/ERROR: ' + str(v.get('error'))}")
    lines.append("")
    lines.append("SAV files:")
    lines.append("TRAIN: " + json.dumps(result["train_sav"], indent=2, default=str))
    lines.append("SCORE: " + json.dumps(result["score_sav"], indent=2, default=str))
    lines.append("")
    lines.append("Embedding benchmark:")
    lines.append(json.dumps(result.get("embedding_benchmark"), indent=2, default=str))
    lines.append("")
    lines.append("Cross-encoder benchmark:")
    lines.append(json.dumps(result.get("cross_encoder_benchmark"), indent=2, default=str))
    lines.append("")
    lines.append("FAISS benchmark:")
    lines.append(json.dumps(result.get("faiss_benchmark"), indent=2, default=str))
    lines.append("")
    lines.append("Sparse SGD benchmark:")
    lines.append(json.dumps(result.get("sparse_sgd_benchmark"), indent=2, default=str))
    lines.append("")
    lines.append("Recommendations:")
    for r in result["recommendations"]:
        lines.append("- " + r)
    lines.append("")
    lines.append("Please paste the System, Packages, Embedding benchmark, Cross-encoder benchmark, and Recommendations sections back to ChatGPT.")
    Path(args.out_txt).write_text("\n".join(lines), encoding="utf-8")
    print("Wrote diagnostics:")
    print(args.out_txt)
    print(args.out_json)
    print("\nTop recommendations:")
    for r in result["recommendations"]:
        print("- " + r)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
