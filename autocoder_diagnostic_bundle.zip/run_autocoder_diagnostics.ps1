<#
Run laptop diagnostics for the NAICS/SOC autocoder from Positron Terminal.
#>
param(
    [string]$ProjectDir = "C:\laborshed_autocode",
    [string]$TrainSav = "C:\laborshed_autocode\laborshed_train.sav",
    [string]$ScoreSav = "C:\laborshed_autocode\Statewide Q1 2026.sav"
)

Set-Location $ProjectDir
.\.venv\Scripts\Activate.ps1

$env:PYTHONUTF8="1"
$env:PYTHONIOENCODING="utf-8"
$env:HF_HOME="$ProjectDir\hf_cache"
$env:HF_HUB_CACHE="$ProjectDir\hf_cache\hub"
$env:HF_HUB_DISABLE_PROGRESS_BARS="1"
$env:OMP_NUM_THREADS="1"
$env:OPENBLAS_NUM_THREADS="1"
$env:MKL_NUM_THREADS="1"
$env:BLIS_NUM_THREADS="1"
$env:NUMEXPR_NUM_THREADS="1"
$env:TOKENIZERS_PARALLELISM="false"

python -u "$ProjectDir\autocoder_laptop_diagnostics.py" `
  --train_sav $TrainSav `
  --score_sav $ScoreSav `
  --out_txt "$ProjectDir\diagnostics_autocoder_laptop.txt" `
  --out_json "$ProjectDir\diagnostics_autocoder_laptop.json" `
  --sample_rows 512 `
  --embedding_model "BAAI/bge-large-en-v1.5" `
  --embedding_backend torch `
  --embedding_batch_sizes "8,16,32" `
  --cross_encoder_model "cross-encoder/ms-marco-MiniLM-L6-v2" `
  --cross_encoder_pairs 64 `
  1> "$ProjectDir\diagnostics_stdout.log" `
  2> "$ProjectDir\diagnostics_stderr.log"

Write-Host "Diagnostics complete. Open/paste: $ProjectDir\diagnostics_autocoder_laptop.txt" -ForegroundColor Green
Get-Content "$ProjectDir\diagnostics_autocoder_laptop.txt" -Tail 80
